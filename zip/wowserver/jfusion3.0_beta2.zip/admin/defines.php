<?php
/**
 * This is the activity module helper file
 *
 */

// Define the path to JFusion's plugins
define('JFUSION_PLUGIN_PATH', JPATH_SITE . '/components/com_jfusion/plugins');
define('JFUSION_PLUGIN_AUTOLOADER_PATH', JPATH_SITE . '/components/com_jfusion');

define('JFUSIONPATH_SITE', JPATH_SITE . '/components/com_jfusion');
define('JFUSIONPATH_ADMINISTRATOR', JPATH_ADMINISTRATOR . '/components/com_jfusion');