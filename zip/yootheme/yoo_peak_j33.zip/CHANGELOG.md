# Changelog


    1.0.3
    # Fixed Sidebar Menu
    ^ Updated UIkit theme according to UIkit 2.15.0

    1.0.2
    # Fixed Submenu Icons

    1.0.1
    # Fixed Headerbar
    # Fixed Style Orange
    # Fixed Sidebar Menu behavior in case there's nothing published

    1.0.0
    + Initial Release



    * -> Security Fix
    # -> Bug Fix
    $ -> Language fix or change
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
