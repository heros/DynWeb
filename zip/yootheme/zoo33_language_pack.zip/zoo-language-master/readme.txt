1. Unpack this language package and goto the
   languague folder of the language you want
   to install.

2. To install the language files for the ZOO extension
   copy the content of "zoo/" to your Joomla
   installation.

3. To install the lanuage file of a specific app
   copy the content of "apps/APPNAME/" to
   "media/zoo/applications/APPNAME" of your Joomla
   installation.

   Do not copy language files of apps that are not installed!

   If you are running PHP 5.3.x please make sure to use an up to date version like PHP 5.3.9!